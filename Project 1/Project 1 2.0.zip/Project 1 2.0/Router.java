package riproute;

import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

//the Router is simulated by a node, connected by links. Router includes 

public class Router implements Runnable{
	//data
	private String RouterName, CIDR;
	//private final String subnetMask = "255.255.255.0";//we will comment this time around
	private Set<Link> links = new HashSet<Link>();
	private boolean isOperable = true;
	private RouteTable table;
	private final int infinity = 17;//16 bits
	
	public Router(String RouterName, String CIDR) {
		
		this.RouterName = RouterName; this.CIDR = CIDR;
	}
	/**
	 * getName: receives the Router's name
	 */
	
	public String getName(){
		return RouterName;
	}
	
	/**
	 * getAddress: Retrieves the router's IP address - CIDR
	 * 
	 * @return node's CIDR IP address
	 */
	public String getAddress(){
		return CIDR;
	}
	
	
	public Set<Link> getLinks(){
		return links;
	}
	
	public Link getCIDRLink(String cidr){
		Link link = null;
		for (Link i:links){
			if (i.getY().CIDR.equals(cidr)){
				link = i;
			}
		}
		return link;
	}
	
	public void addLink(Link link){
		links.add(link);
	}
	
	public boolean isOperable(){
		return isOperable;
	}
	
	/**
	 * receive: Receives a neighbor's routing table and update current
	 * routing table if needed. Also resets the duration timers for the
	 * neighbor who sent the table.
	 * 
	 * @param neighbor The neighbor that is sending the table
	 * @param neighborTable The neighbor's table
	 */
	private void receive(Router neighbor, RouteTable neighborTable){
		try{
			String neighborAddress = neighbor.getAddress();
			
			// Gets both neighbor and router destinations
			List<String> neighborDestinations = neighborTable.getDestinations();
			List<String> nodeDestinations = table.getDestinations();
			
			/* Compares neighbor's route table with current route table
			 and updates when a better value is found */
			for(String neighborDestination : neighborDestinations){
				for(String currentDestination : nodeDestinations){
					if(currentDestination.equals(neighborDestination)){
						int currentMetric = table.getDistanceMetric(currentDestination);
						int neighborMetric = neighborTable.getDistanceMetric(neighborDestination);	
						
						/* if currentNode to the destination cost is lower then the neighbor's, but the next hop is the neighbor
						   then use the neighbor metrics cost */
						if(neighborMetric > currentMetric && table.getNextHop(currentDestination).equals(neighborAddress)){
							int newMetric = neighborMetric + table.getDistanceMetric(neighborAddress);
							if (newMetric> infinity){ newMetric = infinity; table.updateNextHop(currentDestination, "0.0.0.0");}
							table.updateMetric(currentDestination,newMetric);
							// Resets duration timers for destinations
							table.resetTimer(currentDestination);
							table.resetTimer(neighborDestination);
						}
						
						// if neighbor's cost is lower, make sure the path next stop is not back to this router
						if(neighborMetric < currentMetric  && !neighborTable.getNextHop(neighborDestination).equals(CIDR)){
							int newMetric;
							int curNodeToNeighborDistance = table.getDistanceMetric(neighborAddress);
							
							// Resets current neighbor distance to 0 for correct arithmetic
							if(curNodeToNeighborDistance == infinity){
								newMetric = neighborMetric;
							}else{
								newMetric = neighborMetric + curNodeToNeighborDistance;
							}
							// Updates node's routing table
							table.updateMetric(currentDestination, newMetric);
							table.updateNextHop(currentDestination, table.getDestination(neighborAddress));
					
							// Resets duration timers for destinations
							table.resetTimer(currentDestination);
							table.resetTimer(neighborDestination);
						}
					}
				}
			}
			// Resets duration timer for neighbor
			table.resetTimer(neighborAddress);
		}catch(NullPointerException e){
			// Ignore, table hasn't been initialized
		}	
	}
	/**
	 * broadcast: Broadcasts a node's routing table to its neighbors.
	 * Also increments the duration timer for each neighbor who is 
	 * being sent the table.
	 * 
	 * @param nodeTable The node's routing table to broadcast
	 */
	private void broadcast(RouteTable nodeTable){
		
		Set<Link> links = getLinks();
		
		for(Link link : links){
			Router x = link.getX();
			Router y = link.getY();
			
			Router neighbor;
			if(x.getAddress() == CIDR){
				neighbor = y;
			}else{
				neighbor = x;
			}
			
			neighbor.receive(this, nodeTable);
			
			//increments timer for neighbor
			nodeTable.incrementTimer(neighbor.getAddress());
		}
	}
	
	
	//Random number generator
	private Random gen = new Random();
	
	/**
	 * tryToFail: Changes the state of the node to
	 * inoperable 10% of the time
	 */
	private void tryToFail(){
		// Determines if Node fails or not
		if(gen.nextInt(10) <= 1){
			isOperable = false;
		}
	}
	
	public void Fail(){
		isOperable = false;
	}
	
	/**
	 * run: Continuously prints out the router's routing table
	 * every 5 seconds and attempts to fail. If it fails, the thread
	 * terminates.
	 */
	public void run() {
		Set<Router> network = Net.getNet();
		int currentIteration = 0;
		
		// Generate's initial routing table
		table = new RouteTable(this, network);
		
		while(true){
			try {
				/* If node has not failed, print table and 
				   broadcast to neighbors */
				if(isOperable()){
					table.printTable(currentIteration);
					broadcast(table);
				}else{
					synchronized (System.out){
						System.out.println("\nRouter " + RouterName + " has failed!");	
						break;
					}
				}
				
				// Determine if the node has failed or not

					//tryToFail();
				
				Thread.sleep(5000);  //run every 5 seconds
				currentIteration++;				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}	
		}	
	}
}
