package riproute;

import java.util.Scanner;

public class FailRouter implements Runnable{
	private boolean isOperable = true;
	
	public void Fail(){
		isOperable = false;
	}
	/**
	 * this runs the program
	 */
	public void run(){
		String reader;//reads keyboard input
		Scanner keyb = new Scanner(System.in);//keyboard input
		
		while(true){
			try {
				if(isOperable){
					//take a line from the key board for router to fail every 5 seconds
					
					System.out.print("Fail a router by typing its letter: ");
					for (Router n: Net.getNet()){//list all operational routers
						if (n.isOperable()){
							System.out.print(n.getName()+", ");
						}
					}
					System.out.print("anytime then hit return\n");
					
					if (keyb.hasNextLine()){
						reader = keyb.nextLine().toUpperCase();
						if (Net.getRouter(reader)!=null){
							Net.getRouter(reader).Fail();
							synchronized (System.out){
								System.out.println("***** Requesting router "+ reader +" to fail!");
							}
						}else{
							synchronized (System.out){
								System.out.println("Router "+ reader +" doesn't exist");
							}
						}
					}
					
				}else{
					break;
				}
				Thread.sleep(5000);
			}catch (InterruptedException e)	{
				e.printStackTrace();
			}
		}
		keyb.close();
	}

}
