package riproute;

//this is the link between two routers. Cost is added

public class Link {
	private final Router x;
	private final Router y;
	private final int cost;
	private final String port;
	
	/**
	 * creates a link between x and y with cost
	 */
	public Link(Router x, Router y, int cost, String port){
		this.x = x;
		this.y = y;
		this.cost = cost;
		this.port = port;
	}
	/**
	 * getX: retrieve the x Router of the link
	 *
	 * @return the x Router of the link
	 */
	
	public Router getX(){
		return x;
	}
	/**
	 * getY: retrieve the y Router of the link
	 * 
	 * @return the y Router of the link
	 */
	public Router getY(){
		return y;
	}
	/**
	 * getCost: retrieve the cost of the link
	 * 
	 * @return the cost of the link
	 */
	public int getCost(){
		return cost;
	}
	/**
	 * getPort: retrieve the port
	 * 
	 * @return the port
	 */
	public String getPort(){
		return port;
	}
}
