package riproute;


import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * RouteTable.java
 * 
 * This class represents a router's routeTable for the network: destinations, distance metric, and entry duration
 */
public class RouteTable {
	private Router curRouter; 
	
	// Data 
	private List<String> destinationIP = new ArrayList<String>();
	//private List<String> subnetMask = new ArrayList<String>();
	private List<String> nextHopIP = new ArrayList<String>();
	private List<Integer> distanceMetric= new ArrayList<Integer>();
	private List<Router> neighborRouters = new ArrayList<Router>();
	private List<Integer> destinationTimes = new ArrayList<Integer>();
	
	
	//  infinity - > 16
	//private final int infinity = Integer.MAX_VALUE;
	private final int infinity = 17;
	/**
	 * RouteTable: Creates a routing table for a Router (
	 * 
	 * @param Router
	 * @param net
	 */
	public RouteTable(Router Router, Set<Router> networkGraph){
		this.curRouter = Router;
		Set<Link> neighborsLinks = Router.getLinks();
		
		// Construct neighbor Router list
		for(Link curLink : neighborsLinks){
			Router x = curLink.getX();
			Router y = curLink.getY();
			
			Router neighbor;
			if(curRouter.equals(x)){
				neighbor = y;
			}else{
				neighbor = x;
			}
			neighborRouters.add(neighbor);
		}
		
		// Initializes routing table
		for(Router n : networkGraph){
			String curAddress = n.getAddress();
			
			/* If the current Router is not a neighbor of this router,
			 * initialize the distance metric to infinity, and the next hop to 0.0.0.0 
			 * 
			 * Else if the current Router is a neighbor of this router,
			 * Initialize the distance metric to the cost value and correctly set the
			 * next hop value*/
			if( !curAddress.equals(curRouter.getAddress()) && !neighborRouters.contains(n) ){
				destinationIP.add(curAddress);
				//subnetMask.add(n.getSubnetMask());
				distanceMetric.add(infinity);
				nextHopIP.add("0.0.0.0");
				destinationTimes.add(0);
			}else if(neighborRouters.contains(n)){
				int cost = 0;
				
				// Determine the Link cost to the neighbor
				for(Link curLink : neighborsLinks){
					Router x = curLink.getX();
					Router y = curLink.getY();
					
					if(x.equals(n) || y.equals(n)){
						cost = curLink.getCost();
					}
				}
				
				destinationIP.add(curAddress);
				//subnetMask.add(n.getSubnetMask());
				distanceMetric.add(cost);
				nextHopIP.add(n.getAddress());
				destinationTimes.add(0);
			}
		}
	}
	
	/**
	 * updateMetric: Updates the distance metric value for a router
	 * 
	 * @param address - The address to update
	 * @param newMetric - The new distance metric value
	 */
	public void updateMetric(String address, int newMetric){		
		int index = destinationIP.indexOf(address); 
		distanceMetric.set(index, newMetric);
	}
	
	/**
	 * updateNextHop: Updates the next hop value for a router
	 * 
	 * @param address The address to update
	 * @param newHop The new next hop value
	 */
	public void updateNextHop(String address, String newHop){
		int index = destinationIP.indexOf(address);
		nextHopIP.set(index, newHop);
	}
	
	/**
	 * incrementTimer: Increments the duration timer for a specific router
	 * If the duration is greater than 2 ( 5 seconds each), it updates the next hop
	 * and distance metric to infinity.
	 * 
	 * @param address The address to increment
	 */
	public void incrementTimer(String destinationAddress){
		int index = destinationIP.indexOf(destinationAddress);
		
		int duration = destinationTimes.get(index);	
		duration++;
		
		if(duration < 3){
			destinationTimes.set(index, duration);
		}else{
			updateMetric(destinationAddress, infinity);
			updateNextHop(destinationAddress, "0.0.0.0");
			destinationTimes.set(index, duration);
			// update the path using the destination as next hop also
			
			for(int i = 0; i < destinationIP.size(); i++){
				String nextHop = getNextHop(destinationIP.get(i));
				if (destinationAddress.equals(nextHop)){
					updateMetric(destinationIP.get(i), infinity);
					updateNextHop(destinationIP.get(i),"0.0.0.0");
				}
					
			}
			
			
		
		}
	}
	
	/**
	 * resetTimer: Resets the duration timer for a specific router
	 * 
	 * @param address The address to reset
	 */
	public void resetTimer(String address){
		int index = destinationIP.indexOf(address);
		destinationTimes.set(index, 0);
	}
	
	/**
	 * getDestination: Retrieves a specific destination router address
	 * 
	 * @param targetDestination The target router
	 * @return The router address
	 */
	public String getDestination(String targetDestination){
		for(String curDestination : destinationIP){
			if(curDestination.equals(targetDestination)){
				return curDestination;
			}
		}
		
		return null;
	}
	
	/**
	 * getNextHop: Retrieves the next hop router to a destination
	 * 
	 * @param targetDestination The target router
	 * @return The current next hop router to a target router
	 */
	public String getNextHop(String targetDestination){
		int destinationIndex = destinationIP.indexOf(targetDestination);
		
		if(destinationIndex != -1){
			return nextHopIP.get(destinationIndex);
		}else{
			return null;
		}
	}
	
	/**
	 * getDistanceMetric: Retrieves a distance metric to a router
	 * 
	 * @param targetDestination The target router
	 * @return The current distance metric to a target router
	 */
	public int getDistanceMetric(String targetDestination){
		int destinationIndex = destinationIP.indexOf(targetDestination);
		
		if(destinationIndex != -1){
			return distanceMetric.get(destinationIndex);
		}else{
			return 0;
		}
	}
	
	/**
	 * 
	 * @param targetDestination The IP address of the destination router
	 * @return The current duration value for a specific destination
	 */
	public int getDuration(String targetDestination){
		int destinationIndex = destinationIP.indexOf(targetDestination);
		
		if(destinationIndex != -1){
			return destinationTimes.get(destinationIndex);
		}else{
			return 0;
		}
	}
	
	/**
	 * getDestinations: Retrieves a router's destinations
	 * 
	 * @return All of the destinations for the router
	 */
	public List<String> getDestinations() {
		return destinationIP;
	}
	
	/**
	 * printTable: Displays the router's routing table
	 * 
	 * @param duration the time duration that is currently being executed
	 */
	public synchronized void printTable(int duration){
	    String port ="NA";
		synchronized(System.out){
			// Header
			/* System.out.println("\n<time>" + "\t" + "<Router IP>" + "\t" + "<destination IP>"
					+ "\t" + "<destination subnet mask>" + "\t" + "<next hop>" +
					"\t\t\t" + "<metric>" + "\t" + "<Timeout Duration>"); */
			System.out.println("\n<Time>" + "\t" + "<From CIDR>" + "\t" + "<To CIDR>"+ "\t" + "<Router>" + "\t" + "<next hop>" +"\t" + "<metric>" + "\t" + "<RouterPort>"+"\t<5s TimerCount>");
			// Prints table
			for(int i = 0; i < destinationIP.size(); i++){
				String currentDestination = destinationIP.get(i);
				Link lnk = curRouter.getCIDRLink(getNextHop(currentDestination)); // get curRouter's link port with nextHop's CIDR
				if (lnk != null){ port = lnk.getPort() ;}
				
				System.out.print(duration*5 + "\t" + curRouter.getAddress() + "\t" + currentDestination +
						"\t" + curRouter.getName() +  "\t\t" + getNextHop(destinationIP.get(i)) + "\t");
				
				// initial metric and failed Routers
				if(getDistanceMetric(currentDestination) == infinity){
					//System.out.print("\tinfinity" + "\t" + getDuration(currentDestination));
					System.out.print("\tinfinity" + "\t NA\t\t\t"
							+ ""+ getDuration(currentDestination) );
				}else{
					//System.out.print("\t" + getDistanceMetric(currentDestination) + "\t" + getDuration(currentDestination));
					System.out.print("\t" + getDistanceMetric(currentDestination) + "\t" + port + "\t\t" + getDuration(currentDestination));
				}
				
				System.out.println();
			}
		}
	}
}