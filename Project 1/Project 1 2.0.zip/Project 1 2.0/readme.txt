(1) This simulator runs RIPV2 simulation on a visual network from config file; 
with 5 seconds per iteration. This project allows you to manually shut down each node

(2) Build and run 

build java class: 

 javac *.java -d .

build jar : 

 jar cfe RIPv2_test.jar riproute.RIPv2_test riproute/*.class

run jar:    

 java -jar RIPv2_test.jar config2.txt


The config file sets up the entire network



