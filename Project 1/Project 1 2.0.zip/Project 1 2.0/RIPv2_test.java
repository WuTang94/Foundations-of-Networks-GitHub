package riproute;


import java.util.ArrayList;
import java.util.List;




//This file runs the project simulation
public class RIPv2_test {

	public static void main(String[] args){
		List<Thread> routerThreads = new ArrayList<Thread>();
		String inFile = "config2.txt";  // config file goes here. This sets up all nodes 
		
		if(args.length == 1){
			inFile = args[0];
		}
		Net x = new Net(inFile);
		System.out.println("Read Net Configuration from input file:");
		Net.PrintAllRouters();
		Net.PrintNet();
		Net.PrintNeighbors();
		
		//begin simulation:
		try{
			System.out.println("\n Begin Simulation");
			
			// Spawn threads
			for(Router router : x.getNet()){
				Thread curRouter = new Thread(router);
				routerThreads.add(curRouter);
			}
			
			// Start threads
			FailRouter ft = new FailRouter();
			Thread failR= new Thread(ft); failR.start();
			Thread.sleep(5000);
			
			for(Thread curThread : routerThreads){
				curThread.start();
			}
			
			// Join threads
			for(Thread curThread : routerThreads){
				
				curThread.join();
			}
			
			System.out.println("\nAll routers have failed. Simulation terminated.");
			ft.Fail();
		}catch(InterruptedException e){
			e.printStackTrace();
		}
	}
}
