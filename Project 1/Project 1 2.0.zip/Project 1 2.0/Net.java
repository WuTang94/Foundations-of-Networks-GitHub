package riproute;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
//import java.util.Iterator;
import java.util.Set;

public class Net {
	//Network graph data storage structures
	private static Set<Router> networkGraph = new HashSet<Router>();
	
	/**
	 * Parses the input file with links to configure the network
	 * @param inFile
	 * CIDR: xxx.xxx.xxx.xxx/yy , cost: number 1~16
	 * Format :
	 * CIDR1 CIDR2 cost Routername1 Routerport1 Routername2 Routerport2
	 *  
	 */
	
	public Net(String inFile){
		String cidr1, cidr2, name1, name2, port1, port2;
		Router x = null, y = null;
		
		Set<String> RouterNames = new HashSet<String>();
		int cost;	
		String delimiter="[ ]";          // delimiters: space
		BufferedReader input=null;
			
		try{
			FileReader fr = new FileReader(inFile);
		    input = new BufferedReader(fr);
		    
		    String line = "";
		    while (( line = input.readLine()) != null){
		    	String[] words =  line.split(delimiter);
		    	cidr1 = words[0]; cidr2 = words[1]; cost = Integer.parseInt(words[2]);
		    	name1 = words[3]; port1 = words[4]; name2 = words[5]; port2 = words[6];
		    	//creates two nodes if they don't exist
		    	
		    	if (!RouterNames.contains(name1)){
	            	 x = new Router( name1,cidr1); RouterNames.add(name1);
	              }else{
	            	  for( Router n : networkGraph){
	            		 if (n.getName().equals(name1)){x = n;}
	            	 }
	              }
		    	if (!RouterNames.contains(name2)){
	            	 y = new Router( name2,cidr2); RouterNames.add(name2);
	              }else{
	            	  for( Router n : networkGraph){
	            		 if (n.getName().equals(name2)){y = n;}
	            	 }            	  
	              }
		    		// Constructs an Link between previously created nodes
                	Link link1 = new Link(x, y, cost, port1);
                	Link link2 = new Link(y, x, cost, port2);

                    // Adds link to each router
                    x.addLink(link1);
                    y.addLink(link2);
                    
                    // Adds routers to graph
                    networkGraph.add(x);
                    networkGraph.add(y);
		    	
		    }
		}catch (IOException e) {
					e.printStackTrace();
		}
	}
	//gets whole description of the network
	public static Set<Router> getNet(){
		return networkGraph;
	}
	// Print all links of the net
		public static void PrintNet(){
			StringBuilder graph = new StringBuilder();
			System.out.print("NetWorkGraph: \n" );
			for(Router router : networkGraph){
				Set<Link> links = router.getLinks();
				
				// For each Link, print its router and cost
				int counter = 0;
				for(Link link : links){
					graph.append("\t" + link.getX().getAddress() + " to " 
							+ link.getY().getAddress() + " Cost: " + link.getCost() + " Router: "+ link.getX().getName() + " Port: " + link.getPort());
					if(counter < links.size() ){
						graph.append("\n");
					}
					counter++;
				}
			}
			System.out.print(graph);
		}
		// Print all Routers and their neighbors
		public static void PrintNeighbors(){
			System.out.print("All Neighors: \n" );
			for(Router n : networkGraph){
				Set<Link> nlinks = n.getLinks(); System.out.println("Router:"+ n.getName());
				for ( Link l:nlinks){
				 Router x= l.getX(); Router y= l.getY();
				 if (n.equals(y)){				 				 
					 System.out.println("\tNeigbhor:"+ x.getName());
				 }
				 if (n.equals(x)){
					 System.out.println("\tNeigbhor:"+ y.getName());
				 }
				}
			}
		}
		//Print all Routers
		public static void PrintAllRouters(){
			System.out.print("All Routers: " );
			for(Router n : networkGraph){
				System.out.print(" "+n.getName()+" ");
			}
			System.out.print("\n");
		}
		//gets the name of the router
		public static Router getRouter(String name) {
			Router router = null;
			for(Router n : networkGraph){
				if(n.getName().equals(name) && n.isOperable()) { router=n;}
			}
			return router;	
		}

}
