package project2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.nio.ByteBuffer;

public class Tools {
//  AckBits = AckBits[3]AckBits[2]AckBits[1]AckBits[0]
 public static byte[] AckBits = new byte[4];   
 public static int[] AllReceivedSeq = new int[300];  // int[] for all received seq #
 
 public static List<byte[]> PacketList = new ArrayList<byte[]>(); // store send packets for possible re-send, demo only, should be wrap around in real application
 
 public static byte[] GraphbytesArray = null;
 public static long[] sendtime = new long[300]; // 1000 timer for sendpackets, demo only, should be wrap around in real application
 public static long[] acktime = new long[300];  // 1000 timer for packets ack, demo only, should be wrap around in real application
 
 public static int SendSeqnum, BigestRecvSeqnum, TotalReceived;     //  latest sequence numbers for sending and receiving, demo only, value should be wrap around in real application
 public static InetAddress Host;
 private static int Port;
 private static DatagramSocket Socket;
 public static long AvgRTT = 0 ;
 
 /* Throttle: ms per packet , file packet ~ 64528 bytes = 516224 bits, 
 20ms = 50 packets per second = 25811200 bps; ~ 25 Mbps, 
 50ms = 20 packets per second = 10324480 bps; ~ 10 Mbpps
 100ms = 10 packets per second = 5162240 bps, 5 Mbps
 */
 public static int Throttle = 20; 
 
 public Tools(InetAddress host, int port, DatagramSocket socket){   
	 Host = host; Port = port; Socket = socket;
	 SendSeqnum= 0; BigestRecvSeqnum = 0; TotalReceived = 0; 
	 Arrays.fill(sendtime,0); Arrays.fill(acktime,0);
 }
 
 public static void SetAckBits(int bit){  // Set AckBits "bit" position to 1 by shift 1 to left by "bit" and set that bit to 1 using OR; |, bit 0~31
	    if (bit <= 8 ){ AckBits[0] |= 1<< bit;	}
	    if (bit > 8 & bit <= 16){ AckBits[1]  |= (byte) 1<< bit - 8;	}
	    if (bit > 16 & bit <= 24){ AckBits[2] |= (byte) 1<< bit - 16;	}
	    if (bit > 24 & bit <= 32){ AckBits[3] |= (byte) 1<< bit - 24;	}
 }
 // Read the graphic file into GraphbytesArray
 // return the GraphbytesArray size
 public static int ReadFileToBytes(String Filename) {  
     FileInputStream fileInputStream = null;
     	  
     try {
         File file = new File(Filename);
         GraphbytesArray = new byte[(int) file.length()];  // Test Graph - byte[] up to 5 MB, file - 5123 KB, need 81 file packets to send

         //read file into bytes[]
         fileInputStream = new FileInputStream(file);
         fileInputStream.read(GraphbytesArray);

     } catch (IOException e) {  // std exception handling
         e.printStackTrace();
     } finally {
         if (fileInputStream != null) {
             try {
                 fileInputStream.close();
             } catch (IOException e) {
                 e.printStackTrace();
             }
         }
     }
     return GraphbytesArray.length;
 }
//write bytes[] to Filename, "ServerReceived.jpg" etc.
 public static void WriteBytesToFile(byte[] bytes, String Filename){ 
	  	try{
	      File OutFile = new File( Filename);
	      FileOutputStream fos = new FileOutputStream(OutFile);
	      fos.write(bytes);
	      fos.flush();
	      fos.close();
	     } catch (IOException e) {
	      e.printStackTrace();
	     }
	  }
//  send packet 
 public static void SendPacket(byte[] buffer){
	    PacketList.add(buffer);
		try {
			 DatagramPacket snd = new DatagramPacket(buffer,buffer.length, Host, Port);
			 Socket.send(snd);
			 SendSeqnum++; 

			 sendtime[SendSeqnum]=System.currentTimeMillis();	 
		}
		catch (SocketException e) {
			System.out.println("Socket: " + e.getMessage());
		}
		catch (IOException e) {
			System.out.println("IO: "+ e.getMessage());
		}
 }	  
 
 public static void SendAck(int seq ){  // send Ack with Sequence # and bits field
	  byte[] ackbuffer = new byte[12];
	  byte[] FourBytes = new byte[4];
	  int i;
	  
		ackbuffer[0]= 0x02;  // Type set to 0x02, Ack
		ackbuffer[1]= 0x01;  // version set to 0x01
		ByteBuffer.wrap(FourBytes).putInt(seq); // put (int) packets sequence # into FourBytes
		for ( i = 4; i <= 7; i++){ ackbuffer[i] = FourBytes[i-4];}
		
		for ( i = 8; i<= 11; i++){ ackbuffer[i] = AckBits[i-8];}
		
		DatagramPacket reply = new DatagramPacket(ackbuffer,8, Host, Port);
		try {
		  Socket.send(reply);
		} catch (SocketException e) {
			System.out.println("Socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("IO: "+ e.getMessage());
		}
 }
 // Go through the AllReceivedSeq[], set the AckBits[] accordingly
 public static void UpdateActBitsField(){
	 int n;
	 for (int i = TotalReceived; i > TotalReceived-32 & i > 0; i--){
		n = BigestRecvSeqnum - AllReceivedSeq[i];
		SetAckBits(n);
	 }
 }
 
 // copy numofbytes in (byte[]) input starts from offset1 to byte[] buffer starts from offset2
 public static void CopyBytesOffset(byte[] input, byte[] buffer, int offset1, int offset2, int numofbytes){
	  for (int i=0; i < numofbytes; i++){
		  buffer[i+offset2]=input[i+offset1];
	  }
 }
 // Calculate average RTT - RoundTripTime from last 10 packets, if > 255 ms, set throttle to 50 ms
 public static void CalcuAvgRTT_SetThrottle(int seqnum){
	 long AvgRTT = 0 ;
	 if ( seqnum >= 10){
	  for (int i = seqnum -10; i <= seqnum; i++){
		 AvgRTT = AvgRTT + acktime[i] - sendtime[i];
	  }
	  AvgRTT = AvgRTT/10;
	  if (AvgRTT > 250 ){
		 Throttle = 50;
	  }else{
		 Throttle = 20;	 
	  }
	 }
 }
 
 /*getBit() - To get one bit back from a bit string stored in a byte array at the specified position
 Example: posBit = 5. Then the evaluation process 
 of the statement can be described as: 
valByte   : ???????? ???????? ???????? xxyxxxxx
>> 5+1
-----------------------------------------------
          = ???????? ???????? ???????? ?????xxy
& 0x0001  : 00000000 00000000 00000000 00000001
-----------------------------------------------
          = 00000000 00000000 00000000 0000000y
 */
public static int getBit(byte[] data, int pos) {
    int posByte = pos/8; 
    int posBit = pos%8;
    byte valByte = data[posByte];
    int valInt = valByte>>(posBit+1) & 0x0001;
    return valInt;
 }

//setBit() - To set one bit to a bit string at the specified position with the specified bit value: 
public static void setBit(byte[] data, int pos, int val) {
	 int posByte = pos/8; 
	 int posBit = pos%8;
	 byte oldByte = data[posByte];
	      oldByte = (byte) (((0xFF7F>>posBit) & oldByte) & 0x00FF);
	      byte newByte = (byte) ((val<<(8-(posBit+1))) | oldByte);
	      data[posByte] = newByte;
 }
}

