package project2;
import java.net.*;
import java.nio.ByteBuffer;
import java.io.*;

//This will run as the Client of the project
public class GameClient {
	public static void main(String args[]){
		// args give message contents and server hostname
	DatagramSocket aSocket = null;
	byte[] buffer = new byte[16];

	Thread sender, receiver;
	
	if (args.length < 2) {
		 System.out.println("Usage: java GameClient Host <Port number> \n Example java GameClient localhost 5001 \n enter hostname in DOS window or ubuntu terminal to get the hostname");
		 System.exit(1);
	}
	
	try {
	 aSocket = new DatagramSocket();
	 InetAddress aHost =  InetAddress.getByName(args[0]);
	 int serverPort = Integer.valueOf(args[1]).intValue();
	 new Tools(aHost, serverPort, aSocket); 
		
		buffer[0] = 0x08;  // connect
		buffer[1] = 0x01;  // version 1
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		buffer[4] = 0x00;  // seqnum = 0
		buffer[5] = 0x00;
		buffer[6] = 0x00;
		buffer[7] = 0x00;
      for (int i=8; i<= 15; i++){
        	buffer[i]=0x00;
      }
      DatagramPacket  ConnectCall = new DatagramPacket(buffer, 16, aHost, serverPort);
      aSocket.send(ConnectCall);
	 while(true){ // send a connect packet to server, if get ack back, start Send and Receive thread       
		aSocket.receive( ConnectCall ); 
		buffer = ConnectCall.getData();
		
		if (buffer[0] == 0x02){
	    	 System.out.println("\n\nClient starts sending & Receiving");
	    	     	
	    	 Send sendT = new Send();
	    	 Receive recvT = new Receive(aSocket);

	    	 //Spawn sender and receiver threads
	    	 sender = new Thread(sendT);	
	         receiver = new Thread(recvT);
	    	// Start sender and receiver thread
	    	 sender.start();
	    	 receiver.start();
	    	 break; // get out of the while loop
			}
	 }
	 // Join threads
     //sender.join();
     receiver.join();   //exit when all threads were terminated
	}
	catch (SocketException e) {   // std exception handling
		System.out.println("Socket: " + e.getMessage());
	}
	catch (IOException e) {
		System.out.println("IO: "+ e.getMessage());
	}
	catch (InterruptedException e){
		e.printStackTrace();
	}
	finally {
		if (aSocket != null)
		 aSocket.close();
	}
  }
 }
	
