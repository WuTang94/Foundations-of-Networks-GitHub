package project2;

import java.nio.ByteBuffer;

public class Send implements Runnable{
 // Load the 5MB graphic file, compose file packets and send, compose 10 Game data packets and send
  public void run() {	
		  int GraphSize, PackDataSize, NumOfPack, RemainGraphsize, FileByteArrayOffset,i;
		  byte[] FilePacketBuffer = new byte[64528];   // 63k +16 = 63*1024 + 16 bytes header = (64512 + 16) bytes = 64528 bytes
		  byte[] CmdGDataBuffer = new byte[16];
		  byte[] FourBytes = new byte[4]; 				// 4 bytes array for assembling packet
		  byte[] GameDataBytes = new byte[8];
		  		  
	/**
	* read the test file, Test Graph - byte[] may be up to 5~6 MB, file - 5123 KB, 5401 KB files need 82 (81.32) and  86 (85.73) file packets to send
	* Make sure when you change which file you send with this file, the corresponding "Receive.java" file in the Server matches up with the file format
	* Example: if sending a jpg from here, make sure the Receive.jpg file receives a jpg
	*/
		  GraphSize = Tools.ReadFileToBytes("Paris_ISS043-E-93480.jpg"); 
		  RemainGraphsize = GraphSize;
		  
		  NumOfPack = GraphSize/64512+1; 
		  try{

		   
		  for ( i =0; i<10; i++){	  //Compose 10 GameData packets and send
			  CmdGDataBuffer[0] = 0x01; // Type - Command
			  CmdGDataBuffer[1] = 0x01; // version = 1
			  CmdGDataBuffer[2] = 0x00;
			  CmdGDataBuffer[3] = 0x00;
			  ByteBuffer.wrap(FourBytes).putInt(Tools.SendSeqnum+1); // put (int) SendSeqnum+1 into CmdGDataBuffer 	  
			  Tools.CopyBytesOffset(FourBytes, CmdGDataBuffer, 0, 4, 4);
			  String str ="Command"+i; String cmd=str.substring(0,8); GameDataBytes=cmd.getBytes();

			  Tools.CopyBytesOffset(GameDataBytes, CmdGDataBuffer, 0, 8, 8); // put 16 bytes GameData into CmdGDataBuffer
			  Tools.SendPacket(CmdGDataBuffer);
			  System.out.println("Send out Cmd/Gdata Pack:"+Tools.SendSeqnum);
			  
			  Tools.PacketList.add(CmdGDataBuffer);
			  Thread.sleep(Tools.Throttle);  // wait (int) Tools.Throttle ms before send another 
		  }	  

		
		FileByteArrayOffset = 0;
	    for ( i=0; i<NumOfPack; i++ ){  // Compose FilePackets and send
		  FilePacketBuffer[0] = 0x07; // Type - File
		  FilePacketBuffer[1] = 0x01; // version = 1
		  FilePacketBuffer[2] = 0x03; // 0x03 - jpg
		  FilePacketBuffer[3] = 0x01; // File ID = 1
		 
		  ByteBuffer.wrap(FourBytes).putInt(Tools.SendSeqnum+1); // put seqnum :(int) SendSeqnum+1 into FileBuffer	  
		  Tools.CopyBytesOffset(FourBytes, FilePacketBuffer, 0, 4, 4);
		  
		  ByteBuffer.wrap(FourBytes).putInt(NumOfPack); // put (int) total number of packets into FileBuffer
		  Tools.CopyBytesOffset(FourBytes, FilePacketBuffer, 0, 8, 4);
		  
		  ByteBuffer.wrap(FourBytes).putInt(i+1); // put (int) file packet sequence number into FileBuffer
		  Tools.CopyBytesOffset(FourBytes, FilePacketBuffer, 0, 12, 4);
		  if (RemainGraphsize > 64512 ){  // size > 63 Kb
			  PackDataSize = 64512;
		  }else{
			  PackDataSize = RemainGraphsize;
		  }
		  
		  Tools.CopyBytesOffset(Tools.GraphbytesArray,FilePacketBuffer,FileByteArrayOffset,16,PackDataSize); // put file data into FileBuffer
		  RemainGraphsize = RemainGraphsize - PackDataSize; FileByteArrayOffset = FileByteArrayOffset + PackDataSize;
		  Tools.SendPacket(FilePacketBuffer);
		  System.out.println("Send out File Pack:"+Tools.SendSeqnum+" Fpack#:"+(i+1)+" TotalFPack:"+NumOfPack+" RMsize:"+RemainGraphsize);
		  
		  Tools.PacketList.add(FilePacketBuffer);
		  Thread.sleep(Tools.Throttle); // // wait (int) Tools.Throttle ms before send another
	  }
    }
    catch (InterruptedException e) {
		e.printStackTrace();
	}
  }
}
