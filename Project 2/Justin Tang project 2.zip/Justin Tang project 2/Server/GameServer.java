package project2;
import java.net.*;
import java.io.*;

//This is the file that is the Server for the project
public class GameServer {				
	
	public static void main(String args[]){
	InetAddress Host;
	int Port;
	DatagramSocket cSocket = null;
	Thread sender, receiver;
	
	if (args.length < 1) {
		System.out.println("Usage: java GameServer <Port Number>");
		System.exit(1);
	}
//  Max buffer size: (63K + 16 ) bytes = (63*1024+16) bytes = (64512 + 16) bytes =  64528 bytes
	byte[] buffer = new byte[16];   
		
	try {
		int socket_no = Integer.valueOf(args[0]).intValue();
		cSocket = new DatagramSocket(socket_no);
		
		while(true) {					
			// wait for the client to send the 1st connect packet, then start the send & receive thread
			DatagramPacket ConnectCall = new DatagramPacket(buffer,buffer.length);
			cSocket.receive( ConnectCall );
			buffer = ConnectCall.getData();
			Host = ConnectCall.getAddress();
			Port = ConnectCall.getPort();
			// 
			if (buffer[0]==0x08){
	    	 System.out.println("\n\nServer starts sending & Receiving");
	    	 
			 // Pass in Host, Port and Socket to initiate Tools, Send & Receive class, 
	    	 new Tools(Host, Port, cSocket);  
	    	
	    	 Send sendT = new Send();
	    	 Receive recvT = new Receive(cSocket);
	    	
	    	 Tools.SendAck(0);    // send Ack to client for the 1st connect call, seqnum 0
	    	 System.out.println("Send out Ack 0");
	    	 //Spawn sender and receiver threads
	    	 sender = new Thread(sendT);	
	         receiver = new Thread(recvT);
	    	// Start sender and receiver thread
	    	 sender.start();
	    	 receiver.start();
	    	 break; // get out of the while loop
			}
		 }
		 // Join threads
	     sender.join();
	     receiver.join();   //exit when all threads were terminated
	}
	catch (SocketException e) {   // std exception handling
		System.out.println("Socket: " + e.getMessage());
	}
	catch (IOException e) {
		System.out.println("IO: "+ e.getMessage());
	}
	catch (InterruptedException e){
		e.printStackTrace();
	}
	finally {
		if (cSocket != null)
		 cSocket.close();
	 }
	}
	
}
