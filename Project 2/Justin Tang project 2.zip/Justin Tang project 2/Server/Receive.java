package project2;

import java.io.IOException;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

// Identical to the client code
public class Receive implements Runnable{
	DatagramSocket RSocket;

	public static byte[] CmdGdata = new byte[8];
	public static long CurrentTime;
	public static long timer = 1000; // 1000 ms for packet timeout if no ACK
	private static List<byte[]> FileDataList = new ArrayList<byte[]>();  // List for storing file packets data before receiving all packets for a big graph file
	private static List<Integer> FileDataSeqList = new ArrayList<Integer>(); // List for storing file packets seqnum
	private static int FileSeqNum, FileTotalPackNum; 
		
  public Receive(DatagramSocket socket){
		this.RSocket = socket;
  }
  // Assemble all File packets according to fileseq number order, save them to "ServerReceived.jpg"(or png, gif, etc. depending on file format **VERY IMPORTANT!**), then display the resulting file
  private void AssembleFilePacks(int filesize){
	  int index, length, offset = 0;
	  byte[] fbuffer = new byte[filesize];
	  for (int i = 1; i <= FileTotalPackNum; i++){
		  index = FileDataSeqList.indexOf(i);                
                  length = FileDataList.get(index).length;
		  Tools.CopyBytesOffset(FileDataList.get(index), fbuffer, 0, offset, length);
		  offset = offset + length;
	  }
	  Tools.WriteBytesToFile(fbuffer, "ServerReceived.jpg");
	  try{
	    Runtime.getRuntime().exec("eog ./ServerReceived.jpg");  // ubuntu command eog to display the received file
	  }
      catch(IOException e1) {}  
  }
  
  // Go through the AckBits field, find all the ack bit = 0 (no Ack) position n, get the 
  // 
  private void FindLostPacketResend(){
	  int n;   // the check seqnum
	  byte[] FourBytes = new byte[4];
	  for (int i =0; i<=31; i++){
		  if (Tools.getBit(Tools.AckBits, i)== 0 ){
			  n = Tools.SendSeqnum - i;
			  if ( n >= 0){  // valid seqnum
				  if ( timer < ( CurrentTime-Tools.sendtime[n]) ){  // packet seqnum timed out, put current time into Tools.sendtime[seqnum] to avoid re-checking
					  Tools.acktime[n] = CurrentTime;
					  byte[] buffer = Tools.PacketList.get(n);          // Get the old packet into buffer
					  ByteBuffer.wrap(FourBytes).putInt(Tools.SendSeqnum+1); // prepare a new seqnum from the global seqnum -Tools.SendSeqnum + 1
					  
					  Tools.CopyBytesOffset(FourBytes, buffer, 0, 4, 4);  // change the packet seqnum to Tools.SendSeqnum+1
					  Tools.SendPacket(buffer);											  // re-send packet
					  Tools.PacketList.add(buffer);										  // add the re-send packet into Tools.PacketList
				  }
			  }
		  }
	  }
	  
  }
  
  public void run() {
	     InetAddress Host;
	     int Port;
	     int seqnum, i, DataSize, PacketSize, FileSize;
	     byte[] buffer = new byte[64528];   //  For receiving, size (63K + 16 ) bytes = (63*1024+16) bytes = (64512 + 16) bytes =  64528 bytes
	     byte[] FourBytes = new byte[4]; 	     
	     byte Packtype;
	     byte version;
	     
	     FileSize = 0;
		 try {
				while(true) {
					DatagramPacket received = new DatagramPacket(buffer,buffer.length);
					RSocket.receive( received );
					buffer = received.getData();
					DataSize = received.getLength();
					Host = received.getAddress();
					Port = received.getPort();

					 Packtype = buffer[0]; version = buffer[1];  		// unload header 
									
					 if (Packtype == 0x02){                            // Ack packet
						
						Tools.CopyBytesOffset(buffer, FourBytes, 4, 0, 4);    	// unload Ack packet sequence # (int) , start byte 4 get 4 bytes
						seqnum = ByteBuffer.wrap(FourBytes).getInt();
						Tools.CopyBytesOffset(buffer, FourBytes, 8, 0, 4);    	// unload Ack packet bits field, start byte 8 get 4 bytes
						
						 System.out.println("Received Ack Pack:"+seqnum);
						
						CurrentTime =System.currentTimeMillis();				// Update Ack times, detect lost packets and resend
						Tools.acktime[seqnum]=CurrentTime;  
						FindLostPacketResend();		
						Tools.CalcuAvgRTT_SetThrottle(seqnum);                  // Conjestion control
						
					 }else if (Packtype == 0x01 || Packtype == 0x03 ){ 	// Command/GameData packet
						Tools.CopyBytesOffset(buffer, FourBytes, 4, 0, 4);     	// unload packet sequence # (int), start byte 4 get 4 bytes
						seqnum = ByteBuffer.wrap(FourBytes).getInt();						
						
						if (seqnum > Tools.BigestRecvSeqnum){  
							Tools.BigestRecvSeqnum = seqnum;
						}
						Tools.TotalReceived++;
						Tools.AllReceivedSeq[Tools.TotalReceived] = seqnum; // add seqnum to AllReceivedSeq[]
						Tools.UpdateActBitsField();
						Tools.SendAck(seqnum); 
						
						Tools.CopyBytesOffset(buffer, CmdGdata, 8, 0,8);  	  //  unload Command/GameData start byte[8] get 8 bytes
						String s = new String(CmdGdata);
						System.out.println("Received Cmd/Gdata Pack:"+seqnum+" ,  "+s);  //  display it
						
					 }else if (Packtype == 0x07) {                       // file packet
						Tools.CopyBytesOffset(buffer, FourBytes, 4, 0, 4);     // unload packet sequence # (int)  
						seqnum = ByteBuffer.wrap(FourBytes).getInt();
						
						System.out.println("Received File Pack:"+seqnum);
						
						Tools.CopyBytesOffset(buffer, FourBytes, 8, 0, 4);     // unload file total number of packets (int)  
						FileTotalPackNum = ByteBuffer.wrap(FourBytes).getInt();
						Tools.CopyBytesOffset(buffer, FourBytes, 12,0, 4);     // unload file sequence number (int)  
						FileSeqNum = ByteBuffer.wrap(FourBytes).getInt();
						
						byte[] Gbuf = new byte[DataSize - 16];				   // unload file data
						FileSize = FileSize  + DataSize - 16;
						Tools.CopyBytesOffset(buffer, Gbuf, 16, 0, DataSize-16);  
						
						FileDataList.add(Gbuf); FileDataSeqList.add((Integer)FileSeqNum); // add file data and file seqnum to Lists
						System.out.println("Received file data packet, seq#: "+seqnum+" FileSeq#: "+FileSeqNum);  
						
						Tools.TotalReceived++;								      // add seqnum to AllReceivedSeq[]
						Tools.AllReceivedSeq[Tools.TotalReceived] = seqnum; 
						Tools.UpdateActBitsField();
						Tools.SendAck(seqnum); 
						
						if ( FileSeqNum == FileTotalPackNum){                     // Has received all file packets 
							AssembleFilePacks(FileSize);
						}
					 }
					//}
				 }				 
			}
			catch (SocketException e) {
				System.out.println("Socket: " + e.getMessage());
			}
			catch (IOException e) {
				System.out.println("IO: "+ e.getMessage());
			}
			finally {
				if (RSocket != null)
				 RSocket.close();
			 }
			}

}
