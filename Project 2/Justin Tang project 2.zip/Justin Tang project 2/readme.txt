(1) Project2 has two parts; server and client. Make sure you open the two respective folders in
terminal at the same time 

(2) Build and run: 
 Change directory to server and client
 To build each java class: 
  javac [enter name of Java file here].java -d . 
 To build jar file: 
 For server
  jar cfe GameServer.jar project2.GameServer project2/*.class
 For client
  jar cfe GameClient.jar project2.GameClient project2/*.class

(3)run jar:    In different terminal window in a some machine or different machine 
  java -jar GameServer.jar <port>

  java -jar GameClient.jar serverHostName <port>

Example:
 enter command "hostname" in DOS window or ubuntu terminal window to find the machine' hostname
  java -jar GameServer.jar 5001
  java -jar GameClient.jar localhost 5001


Note: to send different types of files, make sure in the "Receive.java" file for each respective directory,
 you match the file format from the "Send.java" file from the opposite depository.

Example: GameServer sends jpg file, make GameClient receive a jpg file
OR: GameClient sends a png file, make GameServer receive a png file



